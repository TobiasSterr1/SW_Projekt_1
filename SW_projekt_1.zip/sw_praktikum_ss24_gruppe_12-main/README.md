# sw-praktikum-ss24-gruppe12

### TEAM 12

![img.png](img.png)

Willi Koljada, 38574  
Nadjibullah Mobinzada Josofzai, 39952  
Svyatoslav Kitayev, 42323  
Ismail Ekinci, 40127
Tobias Sterr, 40221  
Emirhan Bozkurt, 42776

### Requirements Programms
- PyCharm
- Visual Studio Code
- MySQL Workbench

### Requirements Modules/Languages
- Python 3.7 (or Python 3.8)
- Flask
- Flask-Cors
- flask-restx
- React
- mysql-connector

### How to start the Foodmanager App

Step 1: Start MySQL Workbench server.

Step 2: Open PyCharm.
- Run Main.py

Step 3: NPM Start.
- Go to frontend Folder in TERMINAL
- Type npm start in the TERMINAL